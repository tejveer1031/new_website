package other;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import midterm.Vehicle;
import midterm.Wheel;

/**
 *
 * @author srich
 */
public class Midterm {

    public static JFrame environment;
    static JPanel mainPanel;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        environment = new JFrame();
        
        mainPanel = new JPanel();
        
        JButton btnAddPart = new JButton("add part");
        JButton btnRemovePart = new JButton("remove part");
        JButton btnReplacePart = new JButton("replace part");
        
        mainPanel.add(btnAddPart);
        mainPanel.add(btnRemovePart);
        mainPanel.add(btnReplacePart);
        
        environment.setSize(1280, 720);
        environment.setTitle("I DON'T KNOW");
        environment.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        environment.setResizable(false);
        environment.setLocationRelativeTo(null);
        
        environment.add(mainPanel);
        
        environment.setVisible(true);
        
        // To add the fonctionalities:
        Vehicle v = new Vehicle("Toyota", 29000.55f, new ArrayList<>());
        createAddPartBtnFunctionality(btnAddPart, v);
        createRemovePartBtnFunctionality(btnRemovePart, v);
        createReplacePartBtnFunctionality(btnReplacePart, v);
    }
    
    private static void createAddPartBtnFunctionality(JButton btn, Vehicle v){
        class PanelMouseListener implements MouseListener{
            @Override
            public void mouseClicked(MouseEvent e) {
            }
            @Override
            public void mouseEntered(MouseEvent e) {
            }
            @Override
            public void mouseExited(MouseEvent e) {
            }
            @Override
            public void mousePressed(MouseEvent e) {
                addPartReactToClick(v);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        }
        MouseListener listener = new PanelMouseListener();
        btn.addMouseListener(listener);
    }
    
    private static void addPartReactToClick(Vehicle v){
        v.addPart(new Wheel());
        
        JOptionPane.showMessageDialog(mainPanel, "Part added!");
    }
    
    private static void createRemovePartBtnFunctionality(JButton btn, Vehicle v){
        class PanelMouseListener implements MouseListener{
            @Override
            public void mouseClicked(MouseEvent e) {
            }
            @Override
            public void mouseEntered(MouseEvent e) {
            }
            @Override
            public void mouseExited(MouseEvent e) {
            }
            @Override
            public void mousePressed(MouseEvent e) {
                removePartReactToClick(v);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        }
        MouseListener listener = new PanelMouseListener();
        btn.addMouseListener(listener);
    }
    private static void removePartReactToClick(Vehicle v){
        v.removePart(new Wheel());
        
        JOptionPane.showMessageDialog(mainPanel, "Part removed!");
    }
    
    private static void createReplacePartBtnFunctionality(JButton btn, Vehicle v){
        class PanelMouseListener implements MouseListener{
            @Override
            public void mouseClicked(MouseEvent e) {
            }
            @Override
            public void mouseEntered(MouseEvent e) {
            }
            @Override
            public void mouseExited(MouseEvent e) {
            }
            @Override
            public void mousePressed(MouseEvent e) {
                replacePartReactToClick(v);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        }
        MouseListener listener = new PanelMouseListener();
        btn.addMouseListener(listener);
    }
    private static void replacePartReactToClick(Vehicle v){
        v.replacePart(0, new Wheel());
        
        JOptionPane.showMessageDialog(mainPanel, "Part replaced!");
    }
}

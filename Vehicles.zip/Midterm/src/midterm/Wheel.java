package midterm;

import java.util.ArrayList;

/**
 *
 * @author srich
 */
public class Wheel implements Part {

    ArrayList<Part> arrListParts;
    
    @Override
    public void addPart(Part p) {
        arrListParts.add(p);
    }

    @Override
    public void removePart(Part p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void replacePart(int i, Part p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

package midterm;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author srich
 */
public class Car extends Vehicle implements Serializable {
    transient Wheel[] arrWheels;
    
    public Car(String brand, float costInDollars,ArrayList<Part> arrListParts,
            Wheel[] arrWheels){
        super(brand, costInDollars, arrListParts);
        this.arrWheels = arrWheels;
    }
}

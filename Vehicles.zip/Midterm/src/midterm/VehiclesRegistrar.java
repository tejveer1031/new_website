package midterm;

import java.util.ArrayList;

/**
 *
 * @author srich
 */
public class VehiclesRegistrar {
    ArrayList<Vehicle> arrListVehicles;
    long nbVehicles;
    long nbParts;
    
    VehiclesRegistrar(ArrayList<Vehicle> arrListVehicles){
        this.arrListVehicles = arrListVehicles;
        this.nbVehicles = arrListVehicles.size();
        
        for(int i=0; i<arrListVehicles.size(); ++i){
            this.nbParts += arrListVehicles.get(i).arrListParts.size();
        }
    }
}

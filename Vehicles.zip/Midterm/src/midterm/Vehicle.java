package midterm;

import java.util.ArrayList;

/**
 *
 * @author srich
 */
public class Vehicle implements Part {

    String brand;
    float costInDollars;
    ArrayList<Part> arrListParts;
    
    public Vehicle(String brand, float costInDollars,
            ArrayList<Part> arrListParts){
        this.brand = brand;
        this.costInDollars = costInDollars;
        this.arrListParts = arrListParts;
    }
    
    @Override
    public void addPart(Part p) {
        arrListParts.add(p);
    }

    @Override
    public void removePart(Part p) {
        arrListParts.remove(p);
    }

    @Override
    public void replacePart(int i, Part p) {
        arrListParts.set(i, p);
    }
    
}

package midterm;

/**
 *
 * @author srich
 */
public interface Part {
    void addPart(Part p);
    void removePart(Part p);
    void replacePart(int i, Part p);
}
